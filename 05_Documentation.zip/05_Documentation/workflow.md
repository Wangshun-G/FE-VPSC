# FE–VPSC transfer workflow

1. Abaqus/Explicit solves the FRF FE model with the Hill'48–Voce VUMAT.
2. VUMAT stores `D^c` in SDV2–SDV7 and the three independent components of `W_rel^c` in SDV8–SDV10.
3. ODB tensor output provides the integration-point material orientation `Q_k` through `localCoordSystem`.
4. Consecutive orientations give `Delta R_k` and the basis-spin term `Omega_k^g`.
5. The midpoint orientation transforms `D^c + W_rel^c` into the global frame and the recovered basis spin is added.
6. The complete tensor is transformed to the fixed initial specimen frame:

```text
L_k^s = Q_0^T [ Q_mid (D_k^c + W_rel,k^c) Q_mid^T + Omega_k^g ] Q_0
```

7. `L_k^s` is written using the VPSC input-file data format. The example file contains the control line and the row-major tensor order:

```text
nsteps   ictrl   ctrlincr   temp
step   L11   L12   L13   L21   L22   L23   L31   L32   L33   tincr
For the variable velocity-gradient process (`IVGVAR=1`, `ICTRL=7`),
the deformation-history time increment is taken from `tincr` in each row;
`ctrlincr` in the first line is a dummy value.
```

8. VPSC7 uses this input under the variable velocity-gradient option (`IVGVAR=1`).
