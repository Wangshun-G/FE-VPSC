# Illustrative FE parameters for the FE–VPSC workflow example

> **Note:** The values listed below are illustrative and are provided only to demonstrate the organization and data-transfer procedure of the FE–VPSC workflow. They do not correspond to the production FRF model or to the quantitative simulations reported in the manuscript.

| Category | Parameter | Illustrative value / setting |
|---|---|---|
| Solver | Procedure | Abaqus/Explicit |
| Sheet | Thickness | 1.5 mm |
| Element | Type | C3D8R |
| Mesh | Sheet discretization | uniform global 1.0 mm |
| Mesh | Through-thickness elements | 3 |
| Elasticity | E | 45,000 MPa |
| Elasticity | nu | 0.30 |
| Density | rho | 1.75e-9 tonne/mm^3 |
| Hill'48 | r0 | 0.80 |
| Hill'48 | r45 | 1.10 |
| Hill'48 | r90 | 0.90 |
| Voce | sigma0 | 150 MPa |
| Voce | Q | 50 MPa |
| Voce | b | 8.0 |
| Roller | Forming angle | 30 deg |
| Roller | Forming radius | 50 mm |
| Roller | Thickness | 40 mm |
| Process | Roll gap | 1.6 mm |
| Process | Maximum feed velocity | 25 mm/s |
| Process | Physical forming duration | 10 s |
| Contact | Enforcement | penalty |
| Contact | Normal behavior | hard contact |
| Contact | Friction coefficient | 0.15 |
| Explicit | Fixed mass scaling factor | 1.0e4 |
| Explicit | Mass-scaling region | whole model |
| Explicit | Linear / quadratic bulk viscosity | 0.06 / 1.2 |
| Damping | Additional Rayleigh/structural damping | none |
| Element control | Hourglass | enhanced |
| Output | Field output | 40 intervals |

The geometry, mesh, loading conditions, and constitutive parameters above are deliberately generic. Their purpose is only to show which FE settings are relevant to the FE-to-VPSC transfer example. The production-model parameters are not included in this core example.
