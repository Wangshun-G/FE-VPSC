# SDV mapping used by the core example

| SDV | Meaning |
|---|---|
| SDV1 | PEEQ |
| SDV2 | D11^c |
| SDV3 | D22^c |
| SDV4 | D33^c |
| SDV5 | D12^c |
| SDV6 | D23^c |
| SDV7 | D13^c |
| SDV8 | r32 = relSpinInc(1)/dt |
| SDV9 | r13 = relSpinInc(2)/dt |
| SDV10 | r21 = relSpinInc(3)/dt |
| SDV11–19 | optional diagnostic components of L_rel^c = D^c + W_rel^c |

The 3D relative-spin tensor is

```text
W_rel^c = [ 0    -r21   r13
            r21   0    -r32
           -r13   r32   0   ]
```

**SDV11–SDV19 are intermediate quantities and are not the final spatial velocity gradient in the fixed specimen frame.**
