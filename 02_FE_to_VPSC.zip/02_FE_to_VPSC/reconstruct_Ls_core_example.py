# -*- coding: utf-8 -*-
"""Core example: frame-consistent reconstruction of L^s(t) from Abaqus ODB.

Designed for Abaqus 2020 / Python 2.7.
This is a methodological example, not the complete production exporter.
No deviatoric projection is applied.
For IVGVAR=1 and ICTRL=7, the actual time increment is supplied
by tincr in each loading-history row; CTRLINCR here is a dummy value.
"""
from odbAccess import openOdb
import numpy as np
import math
import csv

# ---------------- USER SETTINGS ----------------
ODB_PATH = r'benchmark_or_Frf_model.odb'
STEP_NAME = 'Step-1'
INSTANCE_NAME = 'PLATE-1'
ELEMENT_LABEL = 1
INTEGRATION_POINT = 1
OUT_CSV = 'reconstructed_Ls_history.csv'
OUT_DAT = 'VAR_VEL_GRAD_reconstructed.dat'
VPSC_ICTRL = 7
VPSC_CTRLINCR_DUMMY = 0.025
VPSC_TEMP = 298.0
# ------------------------------------------------
# The reconstruction uses consecutive saved ODB frames.
# Therefore, the saved-frame spacing defines the temporal sampling
# of the FE loading history transferred to VPSC.


def skew(v):
    return np.array([[0.0, -v[2], v[1]],
                     [v[2], 0.0, -v[0]],
                     [-v[1], v[0], 0.0]], dtype=float)


def rotation_vector(R):
    """Principal short-arc rotation vector for a proper rotation matrix."""
    c = 0.5 * (np.trace(R) - 1.0)
    c = max(-1.0, min(1.0, c))
    angle = math.acos(c)
    if angle < 1.0e-12:
        return np.array([0.5*(R[2,1]-R[1,2]),
                         0.5*(R[0,2]-R[2,0]),
                         0.5*(R[1,0]-R[0,1])], dtype=float)
    s = math.sin(angle)
    if abs(s) < 1.0e-12:
        raise RuntimeError('Incremental rotation is too close to pi.')
    axis = np.array([R[2,1]-R[1,2],
                     R[0,2]-R[2,0],
                     R[1,0]-R[0,1]], dtype=float)/(2.0*s)
    return angle*axis


def exp_rotation(theta):
    angle = np.linalg.norm(theta)
    if angle < 1.0e-12:
        return np.eye(3) + skew(theta)
    axis = theta/angle
    K = skew(axis)
    return np.eye(3) + math.sin(angle)*K + (1.0-math.cos(angle))*np.dot(K,K)


def value_at(field, instance, element_label, ip):
    for v in field.values:
        if v.instance.name != instance:
            continue
        if v.elementLabel != element_label:
            continue
        if hasattr(v, 'integrationPoint') and v.integrationPoint != ip:
            continue
        return v
    return None


def get_sdv_1_to_10(frame):
    values = []
    # Common Abaqus output: SDV1, SDV2, ... as individual fields.
    if 'SDV1' in frame.fieldOutputs.keys():
        for i in range(1, 11):
            name = 'SDV%d' % i
            if name not in frame.fieldOutputs.keys():
                raise RuntimeError('%s not found.' % name)
            v = value_at(frame.fieldOutputs[name], INSTANCE_NAME,
                         ELEMENT_LABEL, INTEGRATION_POINT)
            if v is None:
                raise RuntimeError('Location not found in %s.' % name)
            values.append(float(v.data))
        return np.array(values, dtype=float)

    # Fallback if a vector-valued SDV field is present.
    if 'SDV' in frame.fieldOutputs.keys():
        v = value_at(frame.fieldOutputs['SDV'], INSTANCE_NAME,
                     ELEMENT_LABEL, INTEGRATION_POINT)
        if v is None:
            raise RuntimeError('Location not found in SDV field.')
        data = list(v.data)
        if len(data) < 10:
            raise RuntimeError('Need at least SDV1-SDV10.')
        return np.array(data[:10], dtype=float)

    raise RuntimeError('No SDV output found.')


def get_Q(frame):
    if 'S' not in frame.fieldOutputs.keys():
        raise RuntimeError('Stress output S is required to obtain localCoordSystem.')
    v = value_at(frame.fieldOutputs['S'], INSTANCE_NAME,
                 ELEMENT_LABEL, INTEGRATION_POINT)
    if v is None:
        raise RuntimeError('Selected element/IP not found in S.')
    C = np.array(v.localCoordSystem, dtype=float)
    return C.T  # local -> global


def build_Dc(sdv):
    D11,D22,D33,D12,D23,D13 = sdv[1:7]
    return np.array([[D11,D12,D13],
                     [D12,D22,D23],
                     [D13,D23,D33]], dtype=float)


def build_Wrel(sdv):
    r32,r13,r21 = sdv[7],sdv[8],sdv[9]
    return np.array([[0.0,-r21,r13],
                     [r21,0.0,-r32],
                     [-r13,r32,0.0]], dtype=float)


odb = openOdb(path=ODB_PATH, readOnly=True)
try:
    step = odb.steps[STEP_NAME]
    frames = step.frames
    if len(frames) < 2:
        raise RuntimeError('At least two saved states are required.')

    Q0 = get_Q(frames[0])
    rows = []

    for k in range(1, len(frames)):
        f0 = frames[k-1]
        f1 = frames[k]
        dt = f1.frameValue - f0.frameValue
        if dt <= 0.0:
            continue

        sdv = get_sdv_1_to_10(f1)
        Dc = build_Dc(sdv)
        Wrel_c = build_Wrel(sdv)
        Lrel_c = Dc + Wrel_c

        Q_prev = get_Q(f0)
        Q_now = get_Q(f1)
        dR = np.dot(Q_now, Q_prev.T)
        theta = rotation_vector(dR)
        Omega_g = skew(theta/dt)
        Q_mid = np.dot(exp_rotation(0.5*theta), Q_prev)

        Lg = np.dot(np.dot(Q_mid, Lrel_c), Q_mid.T) + Omega_g
        Ls = np.dot(np.dot(Q0.T, Lg), Q0)

        err_Q = np.max(np.abs(np.dot(Q_now.T,Q_now)-np.eye(3)))
        det_Q = np.linalg.det(Q_now)
        rows.append([k, f1.frameValue, dt,
                     Ls[0,0],Ls[0,1],Ls[0,2],
                     Ls[1,0],Ls[1,1],Ls[1,2],
                     Ls[2,0],Ls[2,1],Ls[2,2],
                     err_Q,det_Q])

    with open(OUT_CSV, 'wb') as f:
        wr = csv.writer(f)
        wr.writerow(['frame','time','dt','L11','L12','L13','L21','L22','L23',
                     'L31','L32','L33','err_Q_orth','detQ'])
        wr.writerows(rows)

    with open(OUT_DAT, 'w') as f:
        f.write('%d   %d   %.8g   %.1f         nsteps  ictrl  ctrlincr  temp\n' %
                (len(rows), VPSC_ICTRL, VPSC_CTRLINCR_DUMMY, VPSC_TEMP))
        f.write('step   L11   L12   L13   L21   L22   L23   L31   L32   L33   tincr\n')
        for r in rows:
            f.write('%5d % .8e % .8e % .8e % .8e % .8e % .8e % .8e % .8e % .8e % .8e\n' %
                    (r[0],r[3],r[4],r[5],r[6],r[7],r[8],r[9],r[10],r[11],r[2]))

    print('Wrote %s' % OUT_CSV)
    print('Wrote %s' % OUT_DAT)
finally:
    odb.close()
