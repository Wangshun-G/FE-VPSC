# Coordinate convention

- `c`: current Abaqus corotational material frame.
- `g`: Abaqus global frame.
- `s`: fixed initial specimen frame, initially aligned with RD–TD–ND.

The ODB tensor-field `localCoordSystem` is denoted `C_k` and is treated as the global-to-local direction-cosine matrix. Therefore,

```text
Q_k = C_k^T
```

maps local components to the Abaqus global frame.

For consecutive saved output states:

```text
Delta R_k = Q_k Q_(k-1)^T
Omega_k^g = Log(Delta R_k) / Delta t_k
Q_(k-1/2) = Exp[0.5 Log(Delta R_k)] Q_(k-1)
L_k^g = Q_(k-1/2) (D_k^c + W_rel,k^c) Q_(k-1/2)^T + Omega_k^g
L_k^s = Q_0^T L_k^g Q_0
```

`L_k^s` is the tensor written to the VPSC variable-velocity-gradient file.
