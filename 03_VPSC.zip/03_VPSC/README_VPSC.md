# VPSC input-file data-format example

The example in this folder illustrates the VPSC input-file data format used for variable velocity-gradient loading .

The file begins with the control line

```text
nsteps   ictrl   eqincr   temp
```

followed by the column header and loading increments

```text
step   L11   L12   L13   L21   L22   L23   L31   L32   L33   tincr
```

The nine velocity-gradient components are written in row-major order, and `tincr` is the time increment associated with the loading row. The file provided here is a compact methodological example.
