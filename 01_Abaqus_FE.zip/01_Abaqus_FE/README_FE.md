# Abaqus/Explicit core examples

This folder contains **examples of the core FE definitions only**.

* `vumat_hill48_voce_core_example.f` shows the constitutive coefficient mapping, Voce hardening law, and SDV packing relevant to the FE–VPSC transfer. It is not the complete production VUMAT.

* `abaqus_frf_core_settings_example.inp` is a keyword excerpt illustrating the FE material, numerical, contact, output, and material-orientation definitions required for the FE–VPSC workflow. Geometry, node, element, boundary-condition, roller-motion, and production set definitions are intentionally omitted.

**All numerical values provided in `abaqus_frf_core_settings_example.inp` are illustrative example values only. They are included solely to demonstrate the organization and usage of the relevant Abaqus keywords and do not correspond to the production FRF model or to the quantitative parameters used in the manuscript.**

The example includes representative definitions for the C3D8R sheet model, Hill'48–Voce VUMAT material constants, density, contact settings, mass scaling, field output, and the initial material orientation used to define the specimen RD–TD–ND reference frame.

The example uses 40 field-output intervals for demonstrating the FE-to-VPSC reconstruction procedure. Because the reconstruction evaluates the deformation history from consecutive saved ODB states, the saved-frame spacing defines the temporal discretization of the loading history transferred to VPSC. The value of 40 intervals is therefore an illustrative setting rather than a prescribed or validated production value; an appropriate output-frame density should be established independently for a specific FE model.
