C=======================================================================
C CORE EXAMPLE ONLY -- NOT THE COMPLETE PRODUCTION VUMAT
C
C Hill'48 + isotropic Voce hardening definitions and the corotational
C kinematic quantities used by the FE-to-VPSC transfer.
C
C PROPS:
C   1 E, 2 NU, 3 R0, 4 R45, 5 R90, 6 SIG0, 7 Q, 8 B
C
C STATEV relevant to the transfer:
C   1     PEEQ
C   2-7   D11,D22,D33,D12,D23,D13 in frame c
C   8-10  r32,r13,r21 = relSpinInc/dt components in frame c
C   11-19 optional diagnostic L_rel^c = D^c + W_rel^c
C
C IMPORTANT:
C   relSpinInc/dt is NOT the absolute spatial spin.
C   SDV11-SDV19 are NOT directly imposed on VPSC.
C=======================================================================

      subroutine hill48_coeffs(r0,r45,r90,F,G,H,L,M,N)
      implicit none
      real*8 r0,r45,r90,F,G,H,L,M,N
      real*8 one,two,half
      parameter(one=1.d0,two=2.d0,half=0.5d0)

      F = r0/(r90*(r0+one))
      G = one/(r0+one)
      H = r0/(r0+one)
      N = half*(r0+r90)*(one+two*r45)/(r90*(r0+one))
      L = N
      M = N
      return
      end

      real*8 function voce_yield(peeq,sigma0,q,b)
      implicit none
      real*8 peeq,sigma0,q,b
      voce_yield = sigma0 + q*(1.d0-dexp(-b*peeq))
      return
      end

C=======================================================================
C Example packing of corotational kinematics inside a 3D VUMAT call.
C strainInc and relSpinInc are Abaqus VUMAT arguments.
C=======================================================================
      subroutine pack_corotational_kinematics(dt,strainInc,
     1 relSpinInc,stateNew)
      implicit none
      real*8 dt,strainInc(6),relSpinInc(3),stateNew(30)
      real*8 D11,D22,D33,D12,D23,D13
      real*8 r32,r13,r21
      real*8 L11,L22,L33,L12,L23,L13,L21,L32,L31

      if (dt .gt. 0.d0) then
         D11 = strainInc(1)/dt
         D22 = strainInc(2)/dt
         D33 = strainInc(3)/dt
         D12 = strainInc(4)/dt
         D23 = strainInc(5)/dt
         D13 = strainInc(6)/dt

C        Abaqus VUMAT 3D relSpinInc order: (32,13,21)
         r32 = relSpinInc(1)/dt
         r13 = relSpinInc(2)/dt
         r21 = relSpinInc(3)/dt
      else
         D11 = 0.d0
         D22 = 0.d0
         D33 = 0.d0
         D12 = 0.d0
         D23 = 0.d0
         D13 = 0.d0
         r32 = 0.d0
         r13 = 0.d0
         r21 = 0.d0
      end if

      stateNew(2) = D11
      stateNew(3) = D22
      stateNew(4) = D33
      stateNew(5) = D12
      stateNew(6) = D23
      stateNew(7) = D13
      stateNew(8) = r32
      stateNew(9) = r13
      stateNew(10)= r21

C     Optional intermediate tensor L_rel^c = D^c + W_rel^c.
      L11 = D11
      L22 = D22
      L33 = D33
      L12 = D12-r21
      L21 = D12+r21
      L13 = D13+r13
      L31 = D13-r13
      L23 = D23-r32
      L32 = D23+r32

      stateNew(11)=L11
      stateNew(12)=L22
      stateNew(13)=L33
      stateNew(14)=L12
      stateNew(15)=L23
      stateNew(16)=L13
      stateNew(17)=L21
      stateNew(18)=L32
      stateNew(19)=L31

      return
      end
