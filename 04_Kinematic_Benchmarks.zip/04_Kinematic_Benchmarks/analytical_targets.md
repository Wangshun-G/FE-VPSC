# Analytical targets

## 1. Uniaxial deformation

```text
F = diag(1 + 0.1 t, 1, 1)
L11 = 0.1/(1 + 0.1 t)
all other components = 0
```

## 2. Simple shear

```text
x' = x + gamma z, gamma = 0.1 t
L13 = 0.1 s^-1
L31 = 0
all other components = 0
```

## 3. Pure rigid-body rotation

Rotation about the specimen z axis at 5 degrees over 1 s:

```text
omega = 0.0872665 s^-1
L12 = -omega
L21 = +omega
D = 0
```

## 4. Shear + rigid-body rotation

```text
F = Rz(t) Fs(t)
L12 = -omega
L21 = +omega
L13 = 0.1 cos(omega t)
L23 = 0.1 sin(omega t)
```
