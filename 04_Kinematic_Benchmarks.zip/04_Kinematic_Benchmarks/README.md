# Constitutive-independent kinematic benchmarks

Four single-element tests were used to verify the VUMAT–ODB–Python transfer logic independently of the Mg–Li material calibration.

1. Uniaxial deformation: verifies normal rate-of-deformation storage and transformation.
2. Simple shear: verifies off-diagonal component order and sign convention.
3. Pure rigid-body rotation: verifies recovery of the corotational-basis spin from the ODB orientation history.
4. Shear + rigid-body rotation: verifies objectivity under simultaneous deformation and rigid rotation.

This core-example release includes one complete Abaqus input (`simple_shear_example.inp`) plus the analytical targets and a summary of the verified results for all four cases. The complete set of internal production/benchmark helper scripts is not released.
